from __future__ import annotations

from datetime import date, time
from pathlib import Path
import sys

import pandas as pd
import streamlit as st

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "src"))
from data_profiler import profile_dataframe

st.set_page_config(page_title="OOP Corridor Daily Operations Report", layout="wide")

st.title("OOP Corridor Daily Operations Report")
st.caption("V1 — Data ingestion and quality foundation")

with st.sidebar:
    st.header("Report controls")
    reporting_date = st.date_input("Reporting date", value=date.today())
    period_covered = st.text_input("Period covered", placeholder="e.g. Friday 21 Aug 2026")
    close_time = st.time_input("Data close time", value=time(17, 0))
    st.info("Reporting date and close time are manual inputs. They are never inferred from the latest data timestamp.")

uploaded = st.file_uploader("Upload the operations dataset", type=["xlsx", "xls", "csv"])

if uploaded is None:
    st.markdown("### Start here")
    st.write("Upload the SERSHO workbook or another corridor operations dataset. The source file will be profiled without changing it.")
    st.stop()

try:
    if uploaded.name.lower().endswith(".csv"):
        sheets = {"CSV": pd.read_csv(uploaded, low_memory=False)}
    else:
        workbook = pd.ExcelFile(uploaded)
        sheets = {name: pd.read_excel(uploaded, sheet_name=name) for name in workbook.sheet_names}
except Exception as exc:
    st.error(f"Could not read the file: {exc}")
    st.stop()

st.success(f"Loaded {uploaded.name}")

sheet_name = st.selectbox("Sheet to analyse", list(sheets.keys()))
df = sheets[sheet_name]

st.subheader("Dataset overview")
profile = profile_dataframe(df)
cols = st.columns(6)
metrics = [
    ("Rows", profile.summary["rows"]),
    ("Columns", profile.summary["columns"]),
    ("Duplicate rows", profile.summary["duplicate_rows"]),
    ("Missing cells", profile.summary["total_missing"]),
    ("Date columns", profile.summary["date_columns"]),
    ("Numeric columns", profile.summary["numeric_columns"]),
]
for col, (label, value) in zip(cols, metrics):
    col.metric(label, f"{value:,}")

st.subheader("Report context")
st.write({
    "reporting_date": reporting_date.isoformat(),
    "period_covered": period_covered or "Not specified",
    "data_close_time": close_time.strftime("%H:%M"),
})

st.subheader("Column profile")
st.dataframe(profile.columns, use_container_width=True, hide_index=True)

st.subheader("Data-quality findings")
if profile.issues.empty:
    st.success("No basic quality issues detected by the V1 checks.")
else:
    st.dataframe(profile.issues, use_container_width=True, hide_index=True)

st.subheader("Sample records")
st.dataframe(df.head(20), use_container_width=True, hide_index=True)

st.caption("Next build stage: corridor-specific operational analysis, KPI calculations, insight evidence, and cleaning/audit outputs.")
