# OOP Corridor Daily Operations Report

Fast-build V1 for daily corridor operations analytics.

## Current V1 scope
- Upload Excel/CSV files
- Inspect workbook sheets
- Select the analysis sheet
- Profile columns and data quality
- Detect missing values, duplicates, invalid dates and suspicious numeric values
- Produce a cleaning/audit log without silently changing the source data
- Capture reporting date, period covered and data close time manually
- Preserve the supplied PowerPoint template as the target report structure
- Foundation for the analysis, PowerPoint report and analytical addendum engines

## Important reporting rule
The system does **not** infer the report date or data close time from the latest record timestamp. These are explicit user inputs because a report can be prepared after the period it covers.

## Run on Windows
```powershell
cd path\to\oop_corridor_report
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell execution policy blocks activation, run the Streamlit command using the venv Python directly:
```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```
