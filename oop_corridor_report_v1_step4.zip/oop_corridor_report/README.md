# OOP Corridor Daily Operations Report — V1 Step 4

Windows-first Streamlit application for operational spreadsheet analysis and template-driven PowerPoint reporting.

## Run
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

## Step 4
- Uses the Generic Corridor PowerPoint template.
- Generates a PowerPoint from the current analysis.
- Reporting date, period covered and data close time remain manual.
- Total wards is supplied by the user; it is never inferred.
- Charts are generated from deterministic analysis results.
- Detailed addendum generation and deeper evidence verification are next.
